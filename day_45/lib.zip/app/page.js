
import Link from "next/link";

export default function HomePage() {
  return (
    <main className="home-page">
      <header className="site-header">
        <Link href="/" className="brand">
          <span className="brand-icon">✦</span>
          <span>
            <span className="brand-name">
              Addis <span>Eats</span>
            </span>
            <small>ETHIOPIAN CUISINE</small>
          </span>
        </Link>

        {/* <nav className="main-nav">
          <Link className="active" href="/">Home</Link>
          <Link href="/menu">Our Menu</Link>
          <Link href="/orders">Orders</Link>
          <Link href="/cart">Cart</Link>
          <Link href="/customer-login">Sign In</Link>
          <Link className="order-button" href="/menu">
            Order Online <span>→</span>
          </Link>
        </nav> */}
      </header>

      <section className="hero">
        <div className="hero-content">
          <p className="eyebrow">AUTHENTIC ETHIOPIAN FLAVORS</p>

          <h1>
            A little <span>Ethiopia.</span>
            <br />
            A lot of heart.
          </h1>

          <p className="hero-description">
            Gather around fresh injera, rich stews and
            <br className="desktop-break" /> the warmth of Ethiopian hospitality.
          </p>

          <Link href="/menu" className="explore-button">
            Explore the Menu <span>→</span>
          </Link>

          <p className="location">
            <span>●</span> Addis Ababa, Ethiopia
          </p>
        </div>

        <div className="hero-bottom">
          <span>MADE WITH HEART</span>
          <span>SHARED WITH LOVE</span>
        </div>
      </section>
    </main>
  );
}
